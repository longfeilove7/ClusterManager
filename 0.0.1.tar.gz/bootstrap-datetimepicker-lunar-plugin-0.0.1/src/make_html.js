
'use strict';

module.exports = (day, lunarDay) => {
    return `${day}<br><span class="lunar-text">${lunarDay}</span>`
};
